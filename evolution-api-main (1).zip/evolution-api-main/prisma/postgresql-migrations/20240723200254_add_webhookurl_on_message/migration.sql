-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "webhookUrl" VARCHAR(500);
