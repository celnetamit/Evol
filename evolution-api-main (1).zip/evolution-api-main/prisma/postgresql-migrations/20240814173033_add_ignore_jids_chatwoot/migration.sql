-- AlterTable
ALTER TABLE "Chatwoot" ADD COLUMN     "ignoreJids" JSONB;
