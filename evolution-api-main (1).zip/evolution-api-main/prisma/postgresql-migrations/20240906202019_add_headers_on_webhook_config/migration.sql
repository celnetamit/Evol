-- AlterTable
ALTER TABLE "Webhook" ADD COLUMN     "headers" JSONB;
