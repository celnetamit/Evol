-- AlterTable
ALTER TABLE `IsOnWhatsapp` ADD COLUMN     `lid` VARCHAR(100);
